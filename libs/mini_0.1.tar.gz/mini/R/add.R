add <-
function (x, y) 
{
    x + y
}

Hidden = function (x) {
    return(x+1)
}
